const  express=require('express')
const nodemailer=require("nodemailer")
const mongoose=require("mongoose") 
const fs = require("fs")
const path = require("path")
const app=express()
app.use(express.urlencoded({extended:true}));   
const users=require('./model/user')
mongoose.connect( 'mongodb+srv://swettha04:swe04@jonrecommend.7iyxo95.mongodb.net/atlas?retryWrites=true&w=majority',{useNewUrlParser: true,useUnifiedTopology: true})
    .then((res)=>{
        app.listen(process.env.PORT ||3232,()=>{
        console.log("listening job assist")
    })
  
    console.log("success job assist")})
    .catch((err)=>{console.log(err)})
let transporter1= {
    service: 'gmail',
    auth: {
    user:'jobassist890@gmail.com'    ,
    pass:'nuozplfaefjlwtro',
    },

};

const smtpTransport1 = nodemailer.createTransport(transporter1)


app.post('/sendmail',(req,res)=>{
console.log('in jobassist');
 const mailOptions1 = {
             from:'jobassist890@gmail.com',
            to:req.body.email,
            subject: `Mock Interview Confirmation Mail (JobAssist Chatbot)`,
            html: `Hi ${req.body.name},
            Your Mock interview for ${req.body.domain} has been scheduled on ${req.body.date}(${req.body.slot}).Join the interview using this link(https://meet.google.com/ais-mgdo-jyu)`
                }
        smtpTransport1.sendMail(mailOptions1, function (err, info) {
                    if (err) {
                      console.log(err);
                    } else {
                        console.log('gmail sent 1');
                        res.sendStatus(200)
                    }})
})

// app.get('/get_users',async(req,res)=>{
//     const user=new users({
//         username:'abc',
//         pin:'1234',
//         email:'abc@email.com'
//     })
//     const result=await user.save()
//     console.log(result)
//     res.send(result)
// })

//login 
app.post('/login',(req,res)=>{
    console.log(req.body)
    var pin1=parseInt(req.body.pin)
    users.findOne({username:req.body.username})
    .then((result)=>{
        console.log(result)
        if(result===null)
        {
            res.sendStatus(400)
        }
        else{
            if(result.pin === pin1)
                {console.log('api send')
                res.send(result)
                }
            else{   
                res.sendStatus(400)

                }
        }
                
            })
          
            
            .catch((err)=>{
                console.log(err)
            })
            
        
   
})



app.get('/',(req,res)=>{
 res.send('job assist is working')
})
